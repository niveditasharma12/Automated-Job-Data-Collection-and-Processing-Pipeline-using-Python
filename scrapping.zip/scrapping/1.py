from selenium import webdriver
import pandas as pd
import time
import os
import requests
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
def perform_scrapping():
    excel_reader = pd.read_excel("C://Users//hp//Desktop//sroniyan//selenium.xlsx",sheet_name="dice")
    print(excel_reader.head())
    for i in excel_reader.index:
        step=excel_reader.loc[i,'Event']
        input=excel_reader.loc[i,'Function input']

        if step=="open Browser":
            open=open_browser(input)
        if step=="get_all_url":
            get_url=get_all_url(open)
        if step=="perform_scrapping_on_all_urls":
            jobdetails=excel_reader.loc[i,'Function input']
            scrap_url=perform_scrapping_on_all_url(get_url,excel_reader,jobdetails,open)




def open_browser(url):
    soup = ' '
    os.environ['PATH'] += R";C:\seleniumDriver"
    driver = webdriver.Chrome()
    driver.get(url)
    time.sleep(10)
    all_jobs = driver.find_elements(By.CLASS_NAME, 'dice-job-search')
    return all_jobs


def get_all_url(all_jobs):
    joblink_list = []
    for job in all_jobs:
        result_html = job.get_attribute('innerHTML')
        soup = BeautifulSoup(result_html, 'html.parser')

        joblink = soup.find_all(class_="card-title-link")
        for job in joblink:
            joblink_list.append(job['href'])
    return joblink_list


def perform_scrapping_on_all_url(joblink_list,excel_reader,jobdetails,all_jobs):
    lis = []
    if joblink_list:
        for url in joblink_list:
            r = requests.get(url)
            htmlContent = r.content
            soup = BeautifulSoup(htmlContent, 'html.parser')
            jobDetail = soup.find(class_=jobdetails)

            jobclass_index=excel_reader[excel_reader['Event']=='get_job_desc'].index
            jobclass=excel_reader.loc[jobclass_index[0],'Function input']
            Job_description=get_job_desc(jobclass,soup)

            jobTitle_index = excel_reader[excel_reader['Event'] == 'get_jobTitle '].index
            jobTitle = excel_reader.loc[jobTitle_index[0], 'Function input']
            Job_title=get_jobTitle(jobTitle,soup)

            companyName_index = excel_reader[excel_reader['Event'] == 'get_companyName'].index
            companyName = excel_reader.loc[companyName_index[0], 'Function input']
            company_Name = get_companyName(companyName, soup)

            joblocation_index = excel_reader[excel_reader['Event'] == 'get_jobLocation'].index
            joblocation = excel_reader.loc[joblocation_index[0], 'Function input']
            job_location= get_jobLocation(joblocation, soup)

            jobbudget_index = excel_reader[excel_reader['Event'] == 'get_jobBugdet'].index
            jobbugdet= excel_reader.loc[jobbudget_index[0], 'Function input']
            job_bugdet = get_jobBugdet(jobbugdet, soup)
            params={
             "Job_title":Job_title, "company_Name":company_Name, "job_location":job_location, "job_bugdet":job_bugdet, "Job_description":Job_description,
            }
            lis.append(params)
        convert_excel(lis)
    else:
        for job in all_jobs:
            result_html = job.get_attribute('innerHTML')
            soup = BeautifulSoup(result_html, 'html.parser')

            jobclass_index = excel_reader[excel_reader['Event'] == 'get_job_desc'].index
            jobclass = excel_reader.loc[jobclass_index[0], 'Function input']
            Job_description = get_job_desc(jobclass, soup)

            jobTitle_index = excel_reader[excel_reader['Event'] == 'get_jobTitle '].index
            jobTitle = excel_reader.loc[jobTitle_index[0], 'Function input']
            Job_title = get_jobTitle(jobTitle, soup)

            companyName_index = excel_reader[excel_reader['Event'] == 'get_companyName'].index
            companyName = excel_reader.loc[companyName_index[0], 'Function input']
            company_Name = get_companyName(companyName, soup)

            joblocation_index = excel_reader[excel_reader['Event'] == 'get_jobLocation'].index
            joblocation = excel_reader.loc[joblocation_index[0], 'Function input']
            job_location = get_jobLocation(joblocation, soup)

            jobbudget_index = excel_reader[excel_reader['Event'] == 'get_jobBugdet'].index
            jobbugdet = excel_reader.loc[jobbudget_index[0], 'Function input']
            job_bugdet = get_jobBugdet(jobbugdet, soup)
            params = {
            "Job_title": Job_title, "company_Name": company_Name, "job_location": job_location,
            "job_bugdet": job_bugdet, "Job_description": Job_description,
            }
            lis.append(params)
        convert_excel(lis)

def convert_excel(lis):
    df=pd.DataFrame(lis)
    df.to_excel("dice_python_data.xlsx",index=False)
    print("converted to excel")

def get_job_desc(job_cls,soup):
    try:
        jobDesc = []
        job = soup.find(id=job_cls)
        # print(job.text)
        list_element = job.find_all("li")
        if list_element:
            for li in list_element:
                list_element = li.text
                jobDesc.append(list_element)

            jobDescription = " ".join(jobDesc)
        else:
            job = soup.find(id=job_cls).get_text().strip('\n')
            jobDesc = job.strip('\t')
            jobDescription = jobDesc.replace(u'\xa0', u' ')

    except Exception as e:
        jobDescription=None

    return jobDescription
def get_jobTitle(jobTitle,soup):
    try:
        jobTitle = soup.find(class_=jobTitle).text.replace('\n', '').strip()
    except:
        jobTitle = None
    return jobTitle

def get_companyName(companyName,soup):
    try:
        companyName = soup.find(id=companyName).text.replace('\n', '').strip()
        if not companyName:
            companyName = soup.find(class_=companyName).text.replace('\n', '').strip()
    except:
        companyName = None
    return companyName

def get_jobLocation(joblocation,soup):
    try:
        jobLocatio = soup.find(class_=joblocation).text.replace('\n', '').strip()
        jobLocation = jobLocatio.replace("\t", "").strip()
    except:
        jobLocation = None
    return jobLocation

def get_jobBugdet(jobbugdet,soup):
    try:
        jobBugdet = soup.find(class_=jobbugdet).text.replace('\n', '').strip()

    except:
        jobBugdet = None
    return jobBugdet


if __name__ == '__main__':
    perform_scrapping()