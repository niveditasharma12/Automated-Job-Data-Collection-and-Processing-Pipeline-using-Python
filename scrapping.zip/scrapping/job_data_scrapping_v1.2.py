from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time
import os
import requests
from bs4 import BeautifulSoup
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from lxml import etree


def perform_scrapping(keywords, location, designation):
    f = pd.ExcelFile("angel.co.xlsx")
    result_df = pd.DataFrame(columns=["source", "prospect_link", "job_Title ", "job_description", "company_Name", "job_Location", "duration", "date_of_post", "type_of_employment", "company_website"])
    for sheet in f.sheet_names:
        excel_reader = f.parse(sheet)
        driver = get_chrome_driver(headless=False)
        # excel_reader = pd.read_excel("/Users/himanshusakwaya/Desktop/srn/2022-10/17/selenium xl.xlsx", sheet_name="snagajob")
        excel_reader.fillna("", inplace=True)
        # print(excel_reader.head())
        for i in excel_reader.index:
            step = excel_reader.loc[i, 'Event']
            identifier = excel_reader.loc[i, 'Identifier']
            step_input = excel_reader.loc[i, 'value']
            if step == "open Browser":
                url_domain = excel_reader.loc[i, 'url']
                url_parameter = excel_reader.loc[i, 'url_parameter']
                url_param = create_url_param(url_parameter, keywords, location, designation)
                url = url_domain + url_param
                if identifier == "class":
                    browser_data = open_browser_by_class(driver, url, step_input)
                elif identifier == "id":
                    browser_data = open_browser_by_id(driver, url, step_input)
                else:
                    browser_data = open_browser_by_xpath(driver, url, step_input)
            if step == "get_all_url":
                domain = excel_reader.loc[i, 'url']
                if identifier == "class":
                    get_urls = get_all_url_by_class(browser_data, step_input, domain)
                elif identifier == "id":
                    get_urls = get_all_url_by_id(browser_data, step_input, domain)
                else:
                    get_urls = get_all_url_by_xpath(browser_data, step_input, domain)
            if step=="loop on all urls":
                driver.close()
                df = perform_scraping_on_all_urls(get_urls,excel_reader, identifier, step_input)
                result_df = result_df.append(df, ignore_index=True)
    result_df.to_excel("Scrapped Data.xlsx", index=False)
    return result_df


def perform_scraping_on_all_urls(urls, excel_reader, identifier, step_input):
    read_data_steps = excel_reader[excel_reader["Event"] == "read_data"]
    #print(read_data_steps)
    data_df = pd.DataFrame()
    for url in urls:
        driver = get_chrome_driver(headless=False)
        data_dict = {}
        if identifier == "class":
            browser_data = open_browser_by_class(driver, url, step_input)
        elif identifier == "id":
            browser_data = open_browser_by_id(driver, url, step_input)
        else:
            browser_data = open_browser_by_xpath(driver, url, step_input)
        result_html = browser_data[0].get_attribute('innerHTML')
        soup = BeautifulSoup(result_html, 'html.parser')
        #print(soup)
        for i in read_data_steps.index:
            data_type = read_data_steps.loc[i, "Type"]
            step_identifier = read_data_steps.loc[i, "Identifier"]
            value = read_data_steps.loc[i, "value"]
            tag = read_data_steps.loc[i, "tag"]
            if step_identifier == "id":
                if tag == "li":
                    data = get_data_by_id_from_li(value, soup)
                else:
                    data = get_text_by_id(value, soup)
            elif step_identifier == "class":
                if tag == "li":
                    data = get_data_by_class_from_li(value, soup)
                else:
                    data = get_text_by_class(value, soup)
            elif step_identifier == "xpath":
                data = get_text_by_xpath(value, soup)
                print(data)
            else:
                data = None
            data_dict[data_type] = data
        data_dict["prospect_link"] = url
        data_dict["source"] = get_domain_name(url)

        data_df = data_df.append(data_dict, ignore_index=True)
        #print(data_df)
        driver.close()
    return data_df


def create_url_param(params, keywords, location, designation):
    if type(keywords) == list:
        keywords = ",+".join(keywords)
        keywords = keywords.strip(",+")
    else:
        keywords = keywords.replace(" ", "+")
    if params == "-in-city-of-":
        param_url = str(keywords) + params + str(location)
    else:
        param_dict = {}
        param_list = params.split(", ")
        for param in param_list:
            if param == "q" or param == "keywords" or param == "keyword":
                param_dict[param] = keywords
            elif param == "location" or param == "w" or param == "l":
                param_dict[param] = location
            else:
                param_dict[param] = designation
        param_url = ""
        for key, value in param_dict.items():
            param_url = param_url + str(key) + "=" + str(value) + "&"
        param_url = param_url.strip("&")
        param_url=param_url.strip("=")
    return param_url


def get_chrome_driver(headless=True):
    options = Options()
    options.headless = headless
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    return driver


def open_browser_by_class(driver, url, element_class):
    driver.get(url)
    time.sleep(10)
    all_jobs = driver.find_elements(By.CLASS_NAME, element_class)
    # r = requests.get(url, allow_redirects=True, headers={'User-Agent': 'Google Chrome'})
    # print(r.url)
    # # print(r.headers['Location'])
    # htmlContent = r.content
    # soup = BeautifulSoup(htmlContent, 'html.parser')
    # all_jobs = soup.find_all("div", {"class": "dice-job-search"})  # soup.find(id="searchDisplay-div")
    print(all_jobs)
    return all_jobs


def open_browser_by_id(driver, url, element_id):
    driver.get(url)
    time.sleep(10)
    all_jobs = driver.find_elements(By.ID, element_id)
    print(all_jobs)
    return all_jobs


def open_browser_by_xpath(driver, url, element_id):
    driver.get(url)
    time.sleep(10)
    all_jobs = driver.find_elements(By.XPATH, element_id)
    print(all_jobs)
    return all_jobs


def get_all_url_by_class(all_jobs, cls_name, domain):
    joblink_list = []
    for job in all_jobs:
        result_html = job.get_attribute('innerHTML')
        soup = BeautifulSoup(result_html, 'html.parser')
        #print(soup)
        joblink = soup.find_all(class_=cls_name)
        for job1 in joblink:
            if 'href' in job1.attrs:
                link = domain + job1['href']
                joblink_list.append(link)
        if len(joblink_list) == 0:
            for job1 in joblink:
                a_job = job1.find_all("a")
                for job2 in a_job:
                    if 'href' in job2.attrs:
                        link = domain + job2['href']
                        joblink_list.append(link)
    print(joblink_list)
    return joblink_list


def get_all_url_by_id(all_jobs, id_name, domain):
    joblink_list = []
    for job in all_jobs:
        result_html = job.get_attribute('innerHTML')
        soup = BeautifulSoup(result_html, 'html.parser')

        joblink = soup.find_all(id=id_name)
        for job1 in joblink:
            if 'href' in job1.attrs:
                link = domain + job1['href']
                joblink_list.append(link)
        if len(joblink_list) == 0:
            for job1 in joblink:
                a_job = job1.find_all("a")
                for job2 in a_job:
                    if 'href' in job2.attrs:
                        link = domain + job2['href']
                        joblink_list.append(link)
    print(joblink_list)
    return joblink_list


def get_all_url_by_xpath(all_jobs, xpath, domain):
    try:
        joblink_list = []
        for job in all_jobs:
            result_html = job.get_attribute('innerHTML')
            soup = BeautifulSoup(result_html, 'html.parser')
            print(soup)
            dom = etree.HTML(str(soup))
            elements = dom.xpath(xpath)
            for element in elements:
                link = domain + str(element)
                joblink_list.append(link)
    except Exception as e:
        print(e)
        joblink_list = None
    print(joblink_list)
    return joblink_list


def get_data_by_id_from_li(cls_name, soup):
    print("in get data by id from li")
    try:
        text = []
        job = soup.find(id=cls_name)
        # print(job.text)
        list_element = job.find_all("li")
        for li in list_element:
            list_element = li.text
            text.append(list_element)

        data = " ".join(text)
    except Exception as e:
        data = None
    print(data)
    return data


def get_data_by_class_from_li(cls_name, soup):
    try:
        text = []
        job = soup.find(class_=cls_name)
        # print(job.text)
        list_element = job.find_all("li")
        for li in list_element:
            list_element = li.text
            text.append(list_element)

        data = " ".join(text)
    except Exception as e:
        data = None
    return data


def get_text_by_id(cls_name, soup):
    print("in get data by id")
    try:
        data = ""
        job = soup.find(id=cls_name)
        data1 = job.get_text()
        data1 = data1.replace('\t', '').replace("\n", "").strip()
        data1 = data1.replace(u'\xa0', u'')
        text = []
        p_elements = job.find_all("p")
        for p in p_elements:
            p_element = p.text
            text.append(p_element)
        data2 = " ".join(text)
        text2 = []
        li_elements = job.find_all("li")
        for li in li_elements:
            li_element = li.text
            text2.append(li_element)
        data3 = " ".join(text2)
        if data1 != "" and data1 is not None and not data1.isspace():
            data = data + " " + data1
        if data2 != "" and data2 is not None and not data2.isspace():
            data = data + " " + data2
        if data3 != "" and data3 is not None and not data3.isspace():
            data = data + " " + data3

    except Exception as e:
        data = None
    print(data)
    return data


def get_text_by_class(cls_name, soup):
    try:
        data = ""
        job = soup.find(class_=cls_name)
        data1 = job.get_text()
        data1 = data1.replace('\t', '').replace("\n", "").strip()
        data1 = data1.replace(u'\xa0', u'')
        text = []
        p_elements = job.find_all("p")
        for p in p_elements:
            p_element = p.text
            text.append(p_element)
        data2 = " ".join(text)
        text2 = []
        li_elements = job.find_all("li")
        for li in li_elements:
            li_element = li.text
            text2.append(li_element)
        data3 = " ".join(text2)
        if data1 != "" and data1 is not None and not data1.isspace():
            data = data + " " + data1
        if data2 != "" and data2 is not None and not data2.isspace():
            data = data + " " + data2
        if data3 != "" and data3 is not None and not data3.isspace():
            data = data + " " + data3
    except Exception as e:
        data = None
    return data


def get_text_by_xpath(xpath, soup):
    try:
        dom = etree.HTML(str(soup))
        text = dom.xpath(xpath)[0].text
        data = text.replace('\t', '').replace("\n", "").strip()
        data = data.replace(u'\xa0', u'')
    except Exception as e:
        print(e)
        data = None
    return data


def get_domain_name(website_url):
    website_url = website_url.rstrip('/')
    website_url = website_url.rstrip('#')
    website_url = website_url.rstrip('/')
    website_url = website_url.replace('http://', '')
    website_url = website_url.replace('https://', '')
    website_url = website_url.replace('www.', '')
    website_url = website_url.strip()
    website_url = website_url.lower()
    res = website_url.split('/')
    website_url = res[0].strip()
    website_url = website_url.split(":")[0].strip()
    return website_url


if __name__ == '__main__':
    perform_scrapping("python", "california", "")

 